package com.example.collegemanagementproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class StudentDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

    }
}