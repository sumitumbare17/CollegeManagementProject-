package com.example.collegemanagementproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
public class StudentLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_student_login);
        Button button = findViewById(R.id.login_button);
        EditText email = findViewById(R.id.login_email);
        EditText pass = findViewById(R.id.login_password);
        button.setOnClickListener(v -> {
        if(email.getText().toString().equals("admin") && pass.getText().toString().equals("admin")){
            Intent intent = new Intent(StudentLogin.this, StudentDashboard.class);
            startActivity(intent);
            finish();
        }
        else{
            email.setError("Invalid Email");
            pass.setError("Invalid Password");
        }
        });
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView textView = findViewById(R.id.faculty_text);
        textView.setOnClickListener(v -> {
            Intent intent = new Intent(StudentLogin.this, FacultyLogin.class);
            startActivity(intent);
            finish();
        });

}
    }